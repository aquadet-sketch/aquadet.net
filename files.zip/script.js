// Basic interactions: mobile nav toggle, year fill, and minimal form UX.
document.addEventListener('DOMContentLoaded', function () {
  const navToggle = document.getElementById('nav-toggle');
  const nav = document.getElementById('main-nav');

  navToggle && navToggle.addEventListener('click', () => {
    if (nav.style.display === 'flex') {
      nav.style.display = '';
    } else {
      nav.style.display = 'flex';
      nav.style.flexDirection = 'column';
    }
  });

  // set copyright year
  const y = new Date().getFullYear();
  const yEl = document.getElementById('year');
  if (yEl) yEl.textContent = y;

  // Enhance form UX (Formspree action can be replaced)
  const form = document.getElementById('contact-form');
  if (form) {
    form.addEventListener('submit', async (e) => {
      // let default behaviour proceed if Formspree or server endpoint is configured.
      // Here we add a simple inline validation and a polite UI state.
      const submitBtn = form.querySelector('button[type="submit"]');
      submitBtn.disabled = true;
      submitBtn.textContent = 'Sending...';
      // If you want to send via fetch to an API replace this and prevent default.
      // For now, we allow the form's action to handle submission (e.g., Formspree).
      setTimeout(() => {
        submitBtn.disabled = false;
        submitBtn.textContent = 'Send Message';
      }, 2000);
    });
  }
});