```markdown
# AQUADET CORPORATION — Website

This is a simple, responsive static website for AQUADET CORPORATION showcasing products and contact details.

Files:
- index.html — main page
- styles.css — site styles
- script.js — small interactions
- assets/logo.svg — placeholder logo

How to run locally
1. Place files in a folder and open `index.html` in a browser.
2. Or serve using a static server:
   - Python 3: `python -m http.server 8000`
   - Node (http-server): `npx http-server .`

Customize before publishing
- Replace placeholder phone/email in the About section with real contact details.
- Replace the Formspree action (`https://formspree.io/f/your-form-id`) with your form endpoint or backend API.
- Swap out `assets/logo.svg` with your official logo and add product images as needed.
- Update meta tags (title, description, keywords) for SEO.

Deploying
- Host on GitHub Pages, Netlify, Vercel, or any static webhost.
- For GitHub Pages: push to a repository and enable GitHub Pages in repo settings (use `main` or `gh-pages` branch).

SEO & Trust
- Add structured data (Organization Schema) and an SSL certificate (HTTPS).
- Add product datasheets, safety datasheets (SDS), and certifications to improve credibility.

Need help?
If you want, I can:
- Generate additional pages (Product detail pages, Safety Data Sheets, TDS download links).
- Create a CMS-backed version (Netlify CMS / Sanity / Contentful).
- Prepare assets and imagery or write product datasheets and SEO copy.
```